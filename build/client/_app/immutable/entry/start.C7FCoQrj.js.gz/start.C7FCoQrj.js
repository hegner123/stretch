import{a as t}from"../chunks/entry.CPcRmZXC.js";export{t as start};
